@extends('admin.layouts.master')
@section('content')

<div class="col-md-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Setores</h4>

        <form action="{{route('setores.store')}}" method="POST" class="forms-sample">
        @csrf
            <div class="form-group">
                <label for="exampleInputUsername1">Nome do setor</label>
                <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome do Setor">
            </div>
          <button type="submit" class="btn btn-primary mr-2">Cadastrar</button>
        </form>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <h4 class="card-title">Setores</h4>

      <div class="table-responsive">
        <table id="myTable" class="table table-hover">
          <thead>
            <tr>
              <th>Nome</th>
              <th style="text-align: center">Ações</th>
            </tr>
          </thead>
          <tbody>
                @foreach ($setores as $setor)
                <tr>
                    <td>{{$setor->nome}}</td>
                    <td style="text-align: center"><a href="" data-toggle="modal" data-target="#exampleModal" class="btn btn-primary m-1">Editar</a>
                    <a href="javascript:if(confirm('Deseja realmente excluir a categoria ?')){
                                                window.location.href = ''
                                                }" class="btn btn-danger m-1"> Excluir</a></td>
                </tr>
                @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>


 <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form action="" method="POST" class="forms-sample">
                @csrf
                    <div class="form-group">
                        <label for="exampleInputUsername1">Nome do setor</label>
                        <input type="text" class="form-control" id="nome" name="nome" value="">
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                        <button type="button" class="btn btn-primary">Salvar</button>
                    </div>
            </form>
      </div>
    </div>
  </div>


  @endsection
